import React from 'react';
import { ErrorMessage } from './components/ui/ErrorMessage';

function App() {
  return (
    <div className="min-h-screen bg-gray-100">
      <main className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">
          React TypeScript Project
        </h1>
        <div className="bg-white rounded-lg shadow-md p-6">
          <p className="text-gray-600 mb-4">
            Project structure is set up with:
          </p>
          <ul className="list-disc list-inside space-y-2 text-gray-700">
            <li>React Query for data fetching</li>
            <li>Zod for schema validation</li>
            <li>React Hook Form for form management</li>
            <li>TypeScript for type safety</li>
          </ul>
          <ErrorMessage message="Example error message component" />
        </div>
      </main>
    </div>
  );
}

export default App;